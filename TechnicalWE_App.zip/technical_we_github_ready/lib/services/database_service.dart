import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/customer.dart';
import '../models/issue.dart';
import '../models/installation.dart';

class DatabaseService {
  DatabaseService._();
  static final instance = DatabaseService._();
  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'technical_we.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (database, version) async {
        await database.execute('''
          CREATE TABLE customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            address TEXT NOT NULL,
            notes TEXT NOT NULL
          )
        ''');
        await database.execute('''
          CREATE TABLE issues(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            description TEXT NOT NULL,
            created_at TEXT NOT NULL,
            notes TEXT NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
          )
        ''');
        await database.execute('''
          CREATE TABLE installations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            description TEXT NOT NULL,
            created_at TEXT NOT NULL,
            notes TEXT NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
          )
        ''');
      },
    );
    return _db!;
  }

  Future<List<Customer>> customers({String query = ''}) async {
    final d = await db;
    final q = '%$query%';
    final rows = await d.query(
      'customers',
      where: query.isEmpty ? null : 'name LIKE ? OR phone LIKE ? OR address LIKE ?',
      whereArgs: query.isEmpty ? null : [q, q, q],
      orderBy: 'id DESC',
    );
    return rows.map(Customer.fromMap).toList();
  }

  Future<int> addCustomer(Customer c) async => (await db).insert('customers', c.toMap());

  Future<int> updateCustomer(Customer c) async =>
      (await db).update('customers', c.toMap(), where: 'id = ?', whereArgs: [c.id]);

  Future<int> deleteCustomer(int id) async =>
      (await db).delete('customers', where: 'id = ?', whereArgs: [id]);

  Future<List<Issue>> issues({String query = '', String? status}) async {
    final d = await db;
    final clauses = <String>[];
    final args = <Object?>[];
    if (query.isNotEmpty) {
      clauses.add('description LIKE ? OR notes LIKE ?');
      final q = '%$query%';
      args.addAll([q, q]);
    }
    if (status != null && status.isNotEmpty) {
      clauses.add('status = ?');
      args.add(status);
    }
    final rows = await d.query(
      'issues',
      where: clauses.isEmpty ? null : clauses.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'id DESC',
    );
    return rows.map(Issue.fromMap).toList();
  }

  Future<int> addIssue(Issue x) async => (await db).insert('issues', x.toMap());
  Future<int> updateIssue(Issue x) async =>
      (await db).update('issues', x.toMap(), where: 'id = ?', whereArgs: [x.id]);
  Future<int> deleteIssue(int id) async =>
      (await db).delete('issues', where: 'id = ?', whereArgs: [id]);

  Future<List<Installation>> installations({String query = '', String? status}) async {
    final d = await db;
    final clauses = <String>[];
    final args = <Object?>[];
    if (query.isNotEmpty) {
      clauses.add('description LIKE ? OR notes LIKE ?');
      final q = '%$query%';
      args.addAll([q, q]);
    }
    if (status != null && status.isNotEmpty) {
      clauses.add('status = ?');
      args.add(status);
    }
    final rows = await d.query(
      'installations',
      where: clauses.isEmpty ? null : clauses.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'id DESC',
    );
    return rows.map(Installation.fromMap).toList();
  }

  Future<int> addInstallation(Installation x) async =>
      (await db).insert('installations', x.toMap());
  Future<int> updateInstallation(Installation x) async =>
      (await db).update('installations', x.toMap(), where: 'id = ?', whereArgs: [x.id]);
  Future<int> deleteInstallation(int id) async =>
      (await db).delete('installations', where: 'id = ?', whereArgs: [id]);

  Future<int> count(String table) async {
    final d = await db;
    final result = await d.rawQuery('SELECT COUNT(*) AS c FROM $table');
    return Sqflite.firstIntValue(result) ?? 0;
  }

  Future<int> countWhere(String table, String where, List<Object?> args) async {
    final d = await db;
    final result = await d.rawQuery(
      'SELECT COUNT(*) AS c FROM $table WHERE $where',
      args,
    );
    return Sqflite.firstIntValue(result) ?? 0;
  }
}
