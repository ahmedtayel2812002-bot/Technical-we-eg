class Customer {
  final int? id;
  final String name;
  final String phone;
  final String address;
  final String notes;

  const Customer({
    this.id,
    required this.name,
    required this.phone,
    required this.address,
    required this.notes,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'name': name,
    'phone': phone,
    'address': address,
    'notes': notes,
  };

  factory Customer.fromMap(Map<String, Object?> m) => Customer(
    id: m['id'] as int?,
    name: (m['name'] ?? '') as String,
    phone: (m['phone'] ?? '') as String,
    address: (m['address'] ?? '') as String,
    notes: (m['notes'] ?? '') as String,
  );
}
