class Installation {
  final int? id;
  final int customerId;
  final String description;
  final String createdAt;
  final String notes;
  final String status;

  const Installation({
    this.id,
    required this.customerId,
    required this.description,
    required this.createdAt,
    required this.notes,
    required this.status,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'customer_id': customerId,
    'description': description,
    'created_at': createdAt,
    'notes': notes,
    'status': status,
  };

  factory Installation.fromMap(Map<String, Object?> m) => Installation(
    id: m['id'] as int?,
    customerId: m['customer_id'] as int,
    description: (m['description'] ?? '') as String,
    createdAt: (m['created_at'] ?? '') as String,
    notes: (m['notes'] ?? '') as String,
    status: (m['status'] ?? 'جديد') as String,
  );
}
