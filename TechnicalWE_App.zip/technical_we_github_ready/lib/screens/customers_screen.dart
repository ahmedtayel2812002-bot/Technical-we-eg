import 'package:flutter/material.dart';
import '../models/customer.dart';
import '../services/database_service.dart';

class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});
  @override State<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  final db = DatabaseService.instance;
  final search = TextEditingController();
  List<Customer> items = [];

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final data = await db.customers(query: search.text.trim());
    if (mounted) setState(() => items = data);
  }

  Future<void> _edit([Customer? c]) async {
    final name = TextEditingController(text: c?.name ?? '');
    final phone = TextEditingController(text: c?.phone ?? '');
    final address = TextEditingController(text: c?.address ?? '');
    final notes = TextEditingController(text: c?.notes ?? '');
    final formKey = GlobalKey<FormState>();

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(c == null ? 'إضافة عميل' : 'تعديل العميل'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(children: [
                TextFormField(controller: name, decoration: const InputDecoration(labelText: 'الاسم'), validator: (v) => v!.trim().isEmpty ? 'مطلوب' : null),
                const SizedBox(height: 10),
                TextFormField(controller: phone, decoration: const InputDecoration(labelText: 'الهاتف')),
                const SizedBox(height: 10),
                TextFormField(controller: address, decoration: const InputDecoration(labelText: 'العنوان')),
                const SizedBox(height: 10),
                TextFormField(controller: notes, maxLines: 3, decoration: const InputDecoration(labelText: 'الملاحظات')),
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () {
              if (formKey.currentState!.validate()) Navigator.pop(context, true);
            }, child: const Text('حفظ')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final value = Customer(id: c?.id, name: name.text.trim(), phone: phone.text.trim(), address: address.text.trim(), notes: notes.text.trim());
    if (c == null) await db.addCustomer(value); else await db.updateCustomer(value);
    _load();
  }

  Future<void> _delete(Customer c) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف العميل'),
        content: Text('هل تريد حذف ${c.name}؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true && c.id != null) { await db.deleteCustomer(c.id!); _load(); }
  }

  @override Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('العملاء')),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('عميل')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: TextField(controller: search, onChanged: (_) => _load(), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'بحث بالاسم أو الهاتف أو العنوان'))),
        Expanded(child: items.isEmpty
          ? const Center(child: Text('لا يوجد عملاء حتى الآن'))
          : ListView.builder(itemCount: items.length, itemBuilder: (_, i) {
              final c = items[i];
              return Card(child: ListTile(
                title: Text(c.name),
                subtitle: Text('${c.phone}\n${c.address}'),
                isThreeLine: true,
                onTap: () => _edit(c),
                trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(c)),
              ));
            })),
      ]),
    ),
  );
}
