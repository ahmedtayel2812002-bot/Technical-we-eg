import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../widgets/stat_card.dart';
import 'customers_screen.dart';
import 'issues_screen.dart';
import 'installations_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final db = DatabaseService.instance;
  int customers = 0, issues = 0, installations = 0, openIssues = 0, solvedIssues = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final values = await Future.wait([
      db.count('customers'),
      db.count('issues'),
      db.count('installations'),
      db.countWhere('issues', 'status != ?', ['تم الحل']),
      db.countWhere('issues', 'status = ?', ['تم الحل']),
    ]);
    if (!mounted) return;
    setState(() {
      customers = values[0];
      issues = values[1];
      installations = values[2];
      openIssues = values[3];
      solvedIssues = values[4];
    });
  }

  Future<void> _open(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Technical WE'),
          centerTitle: true,
        ),
        body: RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('لوحة التحكم', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('إدارة العملاء والأعطال والتركيبات من مكان واحد.'),
              const SizedBox(height: 16),
              StatCard(title: 'إجمالي العملاء', value: '$customers', icon: Icons.people),
              StatCard(title: 'إجمالي الأعطال', value: '$issues', icon: Icons.build),
              StatCard(title: 'إجمالي التركيبات', value: '$installations', icon: Icons.router),
              StatCard(title: 'البلاغات المفتوحة', value: '$openIssues', icon: Icons.pending_actions),
              StatCard(title: 'البلاغات المحلولة', value: '$solvedIssues', icon: Icons.check_circle),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () => _open(const CustomersScreen()),
                icon: const Icon(Icons.people),
                label: const Text('إدارة العملاء'),
              ),
              FilledButton.icon(
                onPressed: () => _open(const IssuesScreen()),
                icon: const Icon(Icons.build),
                label: const Text('إدارة الأعطال'),
              ),
              FilledButton.icon(
                onPressed: () => _open(const InstallationsScreen()),
                icon: const Icon(Icons.router),
                label: const Text('إدارة التركيبات'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
