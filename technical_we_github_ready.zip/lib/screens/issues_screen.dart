import 'package:flutter/material.dart';
import '../models/customer.dart';
import '../models/issue.dart';
import '../services/database_service.dart';

class IssuesScreen extends StatefulWidget {
  const IssuesScreen({super.key});
  @override State<IssuesScreen> createState() => _IssuesScreenState();
}

class _IssuesScreenState extends State<IssuesScreen> {
  final db = DatabaseService.instance;
  final search = TextEditingController();
  List<Issue> items = [];
  List<Customer> customers = [];
  String? filter;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final data = await db.issues(query: search.text.trim(), status: filter);
    final cs = await db.customers();
    if (mounted) setState(() { items = data; customers = cs; });
  }

  String customerName(int id) => customers.where((c) => c.id == id).map((c) => c.name).firstOrNull ?? 'عميل محذوف';

  Future<void> _edit([Issue? x]) async {
    if (customers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أضف عميلًا أولًا')));
      return;
    }
    int customerId = x?.customerId ?? customers.first.id!;
    String status = x?.status ?? 'جديد';
    final desc = TextEditingController(text: x?.description ?? '');
    final notes = TextEditingController(text: x?.notes ?? '');
    final formKey = GlobalKey<FormState>();

    final ok = await showDialog<bool>(context: context, builder: (_) => StatefulBuilder(builder: (context, setLocal) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: Text(x == null ? 'إضافة بلاغ عطل' : 'تعديل البلاغ'),
        content: Form(key: formKey, child: SingleChildScrollView(child: Column(children: [
          DropdownButtonFormField<int>(value: customerId, decoration: const InputDecoration(labelText: 'العميل'), items: customers.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(), onChanged: (v) => setLocal(() => customerId = v!)),
          const SizedBox(height: 10),
          TextFormField(controller: desc, maxLines: 3, decoration: const InputDecoration(labelText: 'وصف العطل'), validator: (v) => v!.trim().isEmpty ? 'مطلوب' : null),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(value: status, decoration: const InputDecoration(labelText: 'الحالة'), items: ['جديد','جاري','تم الحل'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) => setLocal(() => status = v!)),
          const SizedBox(height: 10),
          TextFormField(controller: notes, maxLines: 3, decoration: const InputDecoration(labelText: 'ملاحظات الفني')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () { if (formKey.currentState!.validate()) Navigator.pop(context, true); }, child: const Text('حفظ')),
        ],
      ),
    )));
    if (ok != true) return;
    final value = Issue(id: x?.id, customerId: customerId, description: desc.text.trim(), createdAt: x?.createdAt ?? DateTime.now().toIso8601String(), notes: notes.text.trim(), status: status);
    if (x == null) await db.addIssue(value); else await db.updateIssue(value);
    _load();
  }

  Future<void> _delete(Issue x) async {
    if (x.id == null) return;
    await db.deleteIssue(x.id!);
    _load();
  }

  @override Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(title: const Text('الأعطال')),
    floatingActionButton: FloatingActionButton.extended(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('بلاغ')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: Column(children: [
        TextField(controller: search, onChanged: (_) => _load(), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'بحث')),
        const SizedBox(height: 8),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
          FilterChip(label: const Text('الكل'), selected: filter == null, onSelected: (_) { setState(() => filter = null); _load(); }),
          const SizedBox(width: 6),
          ...['جديد','جاري','تم الحل'].map((s) => Padding(padding: const EdgeInsets.only(left: 6), child: FilterChip(label: Text(s), selected: filter == s, onSelected: (_) { setState(() => filter = s); _load(); }))),
        ]),
      ])),
      Expanded(child: items.isEmpty ? const Center(child: Text('لا توجد بلاغات')) : ListView.builder(itemCount: items.length, itemBuilder: (_, i) {
        final x = items[i];
        return Card(child: ListTile(
          title: Text(customerName(x.customerId)),
          subtitle: Text('${x.description}\nالحالة: ${x.status}'),
          isThreeLine: true,
          onTap: () => _edit(x),
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(x)),
        ));
      })),
    ]),
  ));
}
